<script>
	import { onMount } from 'svelte';
	import * as d3 from 'd3';

	const width = 800;
	const height = 500;
	const margin = { top: 20, right: 30, bottom: 50, left: 60 };
	const innerWidth = width - margin.left - margin.right;
	const innerHeight = height - margin.top - margin.bottom;

	let data = $state([]);
	let xAxisG = $state();
	let yAxisG = $state();

	onMount(async () => {
		data = await d3.csv('/earthquakes_M6.0_1year.csv', (d) => ({
			...d,
			depth: +d.depth,
			mag: +d.mag
		}));
	});

	let xScale = $derived(
		d3
			.scaleLinear()
			.domain([0, d3.max(data, (d) => d.depth) ?? 1])
			.range([0, innerWidth])
			.nice()
	);

	// Reversed range: SVG y grows downward, so higher magnitudes go to the top.
	let yScale = $derived(
		d3
			.scaleLinear()
			.domain(d3.extent(data, (d) => d.mag).map((v) => v ?? 0))
			.range([innerHeight, 0])
			.nice()
	);

	$effect(() => {
		d3.select(xAxisG).call(d3.axisBottom(xScale));
		d3.select(yAxisG).call(d3.axisLeft(yScale));
	});
</script>

<svg {width} {height} viewBox="0 0 {width} {height}">
	<g transform="translate({margin.left},{margin.top})">
		<g bind:this={xAxisG} transform="translate(0,{innerHeight})"></g>
		<g bind:this={yAxisG}></g>

		<text x={innerWidth / 2} y={innerHeight + 40} text-anchor="middle">Depth (km)</text>
		<text transform="rotate(-90)" x={-innerHeight / 2} y={-45} text-anchor="middle">
			Magnitude
		</text>

		{#each data as d (d.id)}
			<circle cx={xScale(d.depth)} cy={yScale(d.mag)} r="4" fill="steelblue" fill-opacity="0.7" />
		{/each}
	</g>
</svg>
