<script>
	import Scatterplot from '$lib/Scatterplot.svelte';
</script>

<h1>M6.0+ Earthquakes: Depth vs. Magnitude</h1>
<Scatterplot />
